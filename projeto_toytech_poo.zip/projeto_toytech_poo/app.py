from flask import Flask, render_template, request, redirect, url_for, flash
from models.produto import Produto
from models.empilhadeira import Empilhadeira
from models.fornecedor import Fornecedor
from models.funcionario import Funcionario
from models.sensor import Sensor
from models.solicitador import Solicitador


app = Flask(__name__)
app.secret_key = "chave_secreta"


def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def get_produto_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "descricao": request.form.get("descricao", "").strip(),
        "quantidade": to_int(request.form.get("quantidade",0)),
        "imagem": to_longtext(request.form.get("imagem","")).strip(),
        "preco": to_float(request.form.get("preco"))
    }
def get_fornecedor_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone": to_tel(request.form.get("telefone"))
    }

def get_funcionario_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone": to_tel(request.form.get("telefone")),
        "email": request.form.get("email", "").strip(),
        "senha": request.form.get("senha","").strip(),
        "cargo": request.form.get("cargo","").strip()
    }

def get_empilhadeira_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "descricao": request.form.get("descricao", "").strip(),
        "capacidade_carga": request.form.get("capacidade_carga","").strip(),
        "num_serie": request.form.get("numero_serie", "").strip(),
        "marca": request.form.get("marca","").strip(),
        "quantidade": to_int(request.form.get("quantidade"))
    }

def get_solicitador_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone": to_tel(request.form.get("telefone","")),
        "senha": request.form.get("senha","").strip(),
    }

def get_sensor_form():
    return {
        "modelo_sensor": request.form.get("modelo_sensor", "").strip(),
        "descricao_funcao_sensor": request.form.get("descricao_funcao_sensor", "").strip(),
        "altura_sensor": to_float(request.form.get("altura_sensor")),
        "largura_sensor": to_float(request.form.get("largura_sensor"))
    }

@app.route("/")
def index_produto():
    produtos_baixo = Produto.low_stock()
    return render_template("index.html", produtos_baixo=produtos_baixo)


@app.route("/produtos")
def produtos():
    return render_template("produtos.html", produtos=Produto.find_all(order_by="nome"))


@app.route("/produto/novo")
def novo_produto():
    return render_template("formulario_produto.html", produto=None)


@app.route("/produto/salvar", methods=["POST"])
def salvar_produto():
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_produto.html", produto=dados)

    try:
        produto.insert()
        flash("Produto cadastrado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        flash(f"Erro ao cadastrar produto: {e}", "erro")
        return render_template("formulario_produto.html", produto=dados)


@app.route("/produto/editar/<int:id>")
def editar_produto(id):
    produto = Produto.find_by_id(id)
    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))
    return render_template("formulario_produto.html", produto=produto)


@app.route("/produto/atualizar/<int:id>", methods=["POST"])
def atualizar_produto(id):
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("formulario_produto.html", produto=dados)

    try:
        if not Produto.find_by_id(id):
            flash("Produto não encontrado.", "erro")
            return redirect(url_for("produtos"))

        produto.update(id)
        flash("Produto atualizado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar produto: {e}", "erro")
        return render_template("formulario_produto.html", produto=dados)


@app.route("/produto/excluir/<int:id>")
def excluir_produto(id):
    try:
        Produto.safe_delete(id)
        flash("Produto excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir produto: {e}", "erro")
    return redirect(url_for("produtos"))

@app.route("/empilhadeira")
def index_emp():
    empilhadeira_baixa = Empilhadeira.low_stock()
    return render_template("index.html", empilhadeira_baixa=empilhadeira_baixa)


@app.route("/empilhadeira/nova")
def nova_empilhadeira():
    return render_template("emp.html", empilhadeira=None)


@app.route("/empilhadeira/salvar", methods=["POST"])
def salvar_empilhadeira():
    dados = get_empilhadeira_form()
    empilhadeira = Empilhadeira(**dados)
    erros = empilhadeira.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("emp.html", empilhadeira=dados)

    try:
        empilhadeira.insert()
        flash("Empilhadeira cadastrada com sucesso.", "sucesso")
        return redirect(url_for("emp"))
    except Exception as e:
        flash(f"Erro ao cadastrar a empilhadeira: {e}", "erro")
        return render_template("emp.html", empilhadeira=dados)


@app.route("/empilhadeira/editar/<int:id>")
def editar_empilhadeira(id):
    empilhadeira = Empilhadeira.find_by_id(id)
    if not empilhadeira:
        flash("Empilhadeira não encontrado.", "erro")
        return redirect(url_for("emp"))
    return render_template("emp.html", empilhadeira=empilhadeira)


@app.route("/empilhadeira/atualizar/<int:id>", methods=["UPDATE"])
def atualizar_empilhadeira(id):
    dados = get_empilhadeira_form()
    empilhadeira = Empilhadeira(**dados)
    erros = empilhadeira.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("emp.html", empilhadeira=dados)

    try:
        if not Empilhadeira.find_by_id(id):
            flash("Empilhadeira não encontrado.", "erro")
            return redirect(url_for("emp"))

        empilhadeira.update(id)
        flash("Empilhadeira atualizada com sucesso.", "sucesso")
        return redirect(url_for("emp"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar empilhadeira: {e}", "erro")
        return render_template("emp.html", empilhadeira=dados)


@app.route("/empilhadeira/excluir/<int:id>")
def excluir_empilhadeira(id):
    try:
        Empilhadeira.safe_delete(id)
        flash("Empilhadeira excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir empilhadeira: {e}", "erro")
    return redirect(url_for("emp"))

@app.route("/sensor")
def sensores():
    return render_template("sensor.html", sensor=Sensor.find_all(order_by="sensor"))


@app.route("/sensor/novo")
def novo_sensor():
    return render_template("sensor.html", sensor=None)


@app.route("/sensor/salvar", methods=["POST"])
def salvar_sensor():
    dados = get_sensor_form()
    sensor = Sensor(**dados)
    erros = sensor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("sensor.html", sensor=dados)

    try:
        sensor.insert()
        flash("O sensor foi cadastrado com sucesso.", "sucesso")
        return redirect(url_for("sensor"))
    except Exception as e:
        flash(f"Erro ao cadastrar o sensor: {e}", "erro")
        return render_template("sensor.html", sensor=dados)


@app.route("/sensor/editar/<int:id>")
def editar_sensor(id):
    sensor = Sensor.find_by_id(id)
    if not sensor:
        flash("Sensor não encontrado.", "erro")
        return redirect(url_for("sensor"))
    return render_template("sensor.html", sensor=sensor)


@app.route("/sensor/atualizar/<int:id>", methods=["POST"])
def atualizar_sensor(id):
    dados = get_sensor_form()
    sensor = Sensor(**dados)
    erros = sensor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("sensor.html", sensor=dados)

    try:
        if not Sensor.find_by_id(id):
            flash("Sensor não encontrado.", "erro")
            return redirect(url_for("sensor"))

        sensor.update(id)
        flash("Sensor atualizado com sucesso.", "sucesso")
        return redirect(url_for("sensor"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar o sensor: {e}", "erro")
        return render_template("sensor.html", sensor=dados)


@app.route("/sensor/excluir/<int:id>")
def excluir_sensor(id):
    try:
        Sensor.safe_delete(id)
        flash("Sensor foi excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir o sensor: {e}", "erro")
    return redirect(url_for("sensor"))


@app.route("/fornecedor")
def produtos():
    return render_template("for.html", fornecedor=Fornecedor.find_all(order_by="nome"))

@app.route("/api/fornecedor/<int:id>")
def api_fornecedor(id):
    fornecedor = Fornecedor.find_by_id(id)

    if not fornecedor:
        return {"erro": "Fornecedor não encontrado"}, 404

    return {
        "id": fornecedor.id,
        "nome": fornecedor.nome,
        "cnpj": fornecedor.cnpj,
        "telefone": fornecedor.telefone
    }
    
@app.route("/fornecedor/novo")
def novo_fornecedor():
    return render_template("for.html", fornecedor=None)


@app.route("/fornecedor/salvar", methods=["POST"])
def salvar_fornecedor():
    dados = get_fornecedor_form()
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("for.html", fornecedor=dados)

    try:
        fornecedor.insert()
        flash("Fornecedor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "erro")
        return render_template("for.html", fornecedor=dados)


@app.route("/fornecedor/editar/<int:id>")
def editar_fornecedor(id):
    fornecedor = Fornecedor.find_by_id(id)
    if not fornecedor:
        flash("Fornecedor não encontrado.", "erro")
        return redirect(url_for("fornecedor"))
    return render_template("for.html", fornecedor=fornecedor)


@app.route("/fornecedor/atualizar/<int:id>", methods=["POST"])
def atualizar_fornecedor(id):
    dados = get_fornecedor_form()
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("for.html", fornecedor=dados)

    try:
        if not Fornecedor.find_by_id(id):
            flash("Fornecedor não encontrado.", "erro")
            return redirect(url_for("fornecedor"))

        fornecedor.update(id)
        flash("Fornecedor atualizado com sucesso.", "sucesso")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar fornecedor: {e}", "erro")
        return render_template("for.html", fornecedor=dados)


@app.route("/fornecedor/excluir/<int:id>")
def excluir_fornecedor(id):
    try:
        Fornecedor.safe_delete(id)
        flash("Fornecedor excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir fornecedor: {e}", "erro")
    return redirect(url_for("fornecedor"))


@app.route("/funcionario")
def funcionario():
    return render_template("fun.html", funcionario=Funcionario.find_all(order_by="nome"))

@app.route("/api/funcionario/<int:id>")
def api_funcionario(id):
    funcionario = Funcionario.find_by_id(id)

    if not funcionario:
        return {"erro": "Funcionario não encontrado"}, 404

    return {
        "id": funcionario.id,
        "nome": funcionario.nome,
        "email": funcionario.email,
        "senha": funcionario.senha,
        "cpf": funcionario.cpf,
        "telefone": funcionario.telefone,
        "cargo": funcionario.cargo
    }
    
@app.route("/funcionario/novo")
def novo_funcionario():
    return render_template("fun.html", funcionario=None)


@app.route("/funcionario/salvar", methods=["POST"])
def salvar_funcionario():
    dados = get_funcionario_form()
    funcionario = Funcionario(**dados)
    erros = funcionario.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("fun.html", funcionario=dados)

    try:
        funcionario.insert()
        flash("Funcionario cadastrado com sucesso.", "sucesso")
        return redirect(url_for("funcionario"))
    except Exception as e:
        flash(f"Erro ao cadastrar funcionario: {e}", "erro")
        return render_template("fun.html", funcionario=dados)


@app.route("/funcionario/editar/<int:id>")
def editar_funcionario(id):
    funcionario = Funcionario.find_by_id(id)
    if not funcionario:
        flash("Funcionario não encontrado.", "erro")
        return redirect(url_for("funcionario"))
    return render_template("fun.html", funcionario=funcionario)


@app.route("/funcionario/atualizar/<int:id>", methods=["POST"])
def atualizar_funcionario(id):
    dados = get_funcionario_form()
    funcionario = Funcionario(**dados)
    erros = funcionario.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("fun.html", funcionario=dados)

    try:
        if not Funcionario.find_by_id(id):
            flash("Funcionario não encontrado.", "erro")
            return redirect(url_for("funcionario"))

        funcionario.update(id)
        flash("Funcionario atualizado com sucesso.", "sucesso")
        return redirect(url_for("funcionario"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar funcionario: {e}", "erro")
        return render_template("fun.html", funcionario=dados)


@app.route("/funcionario/excluir/<int:id>")
def excluir_funcionario(id):
    try:
        Funcionario.safe_delete(id)
        flash("Funcionario excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir funcionario: {e}", "erro")
    return redirect(url_for("funcionario"))

@app.route("/solicitador")
def solicitador():
    return render_template("cad_sol.html", solicitador=Solicitador.find_all(order_by="nome"))

@app.route("/api/solicitador/<int:id>")
def api_solicitador(id):
    solicitador = Solicitador.find_by_id(id)

    if not solicitador:
        return {"erro": "Solicitador não encontrado"}, 404

    return {
        "id": solicitador.id,
        "nome": solicitador.nome,
        "senha": solicitador.senha,
        "cnpj": solicitador.cnpj,
        "telefone": solicitador.telefone
    }
    
@app.route("/solicitador/novo")
def novo_solicitador():
    return render_template("cad_sol.html", solicitador=None)


@app.route("/solicitador/salvar", methods=["POST"])
def salvar_solicitador():
    dados = get_solicitador_form()
    solicitador = Solicitador(**dados)
    erros = solicitador.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("cad_sol.html", solicitador=dados)

    try:
        solicitador.insert()
        flash("Solicitador cadastrado com sucesso.", "sucesso")
        return redirect(url_for("solicitador"))
    except Exception as e:
        flash(f"Erro ao cadastrar solicitador: {e}", "erro")
        return render_template("cad_sol.html", solicitador=dados)


@app.route("/solicitador/editar/<int:id>")
def editar_solicitador(id):
    solicitador = Solicitador.find_by_id(id)
    if not solicitador:
        flash("Solicitador não encontrado.", "erro")
        return redirect(url_for("solicitador"))
    return render_template("cad_sol.html", solicitador=solicitador)


@app.route("/solicitador/atualizar/<int:id>", methods=["POST"])
def atualizar_solicitador(id):
    dados = get_solicitador_form()
    solicitador = Solicitador(**dados)
    erros = solicitador.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("cad_sol.html", solicitador=dados)

    try:
        if not Solicitador.find_by_id(id):
            flash("Solicitador não encontrado.", "erro")
            return redirect(url_for("solicitador"))

        solicitador.update(id)
        flash("Solicitador atualizado com sucesso.", "sucesso")
        return redirect(url_for("solicitador"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar solicitador: {e}", "erro")
        return render_template("cad_sol.html", solicitador=dados)


@app.route("/solicitador/excluir/<int:id>")
def excluir_solicitador(id):
    try:
        Solicitador.safe_delete(id)
        flash("Solicitador excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir solicitador: {e}", "erro")
    return redirect(url_for("solicitador"))


if __name__ == "__main__":
    app.run(debug=True)
