#imports
from datetime import datetime
from core.crud import Crud
from core.conexao import Database

#classe que representa uma movimentacao no sistema
class Movimentacao(Crud):
    table = "movimentacao"
    #lista de campos da tabela
    fields = ["produto_id", "tipo_movimentacao", "quantidade", "data_movimentacao"]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, produto_id, tipo_movimentacao, quantidade, data_movimentacao=None):
        #atribui os valores aos objetos
        self.produto_id = produto_id
        self.tipo_movimentacao = tipo_movimentacao
        self.quantidade = quantidade
        self.data_movimentacao = data_movimentacao or datetime.now()

    #metodo para achar todos as movimentacoes com produto
    @classmethod
    def find_all_with_product(cls):
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
            SELECT m.id, p.nome AS produto, m.tipo_movimentacao, m.quantidade, m.data_movimentacao
            FROM movimentacao m
            INNER JOIN produto p ON m.produto_id = p.id
            ORDER BY m.data_movimentacao DESC
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()
