#imports

from core.conexao import Database
from core.validar import Validador

#classe que representa uma empilhadeira no sistema
class Empilhadeira:
    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome=None, descricao=None, id=None, capacidade_carga=None, marca=None, numero_serie=None, quantidade = 0):
        #atribui os valores aos objetos
        self.id = id
        self.nome = nome
        self.descricao = descricao
        self.capacidade_carga = capacidade_carga
        self.numero_serie = numero_serie
        self.marca = marca
        self.quantidade = quantidade    
    
    #cadastro de empilhadeira
    def cadastrar(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO empilhadeira
        (nome, descricao, capacidade_carga, numero_serie, marca, quantidade)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        valores = (
            self.nome,
            self.descricao,
            self.capacidade_carga,
            self.numero_serie,
            self.marca,
            self.quantidade
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #valida os dados da empilhadeira
    def validate(self):
        #lista de possiveis erros
        erros = [
             Validador.required(self.nome, "nome"),
             Validador.non_negative(self.descricao, "descrição"),
             Validador.non_negative(self.capacidade_carga, "capacidade de carga"),
             Validador.non_negative(self.marca, "marca"),
             Validador.non_negative(self.quantidade, "quantidade"),
             Validador.non_negative(self.numero_serie, "número de série") 
            ]
        #retorna os erros
        return [erro for erro in erros if erro]
    
    ##metodo para listar empilhadeira
    @staticmethod
    def listar():
        #conexao com o banco
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM empilhadeira ORDER BY nome"
        cursor.execute(sql)
        Empilhadeira = cursor.fetchall()

        cursor.close()
        conexao.close()
        return Empilhadeira

    #metodo para buscar o id de empilhadeira
    @staticmethod
    def buscar_por_id(id):
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM empilhadeira WHERE id = %s"
        cursor.execute(sql, (id,))
        Empilhadeira = cursor.fetchone()

        cursor.close()
        conexao.close()
        return Empilhadeira

    #metodo para atualizar empilhadeira
    def atualizar(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        UPDATE empilhadeira
        SET nome = %s,
            descricao = %s,
            capacidade_carga = %s,
            marca = %s,
            numero_medida = %s,
            quantidade = %s
        WHERE id = %s
        """
        valores = (
            self.nome,
            self.descricao,
            self.capacidade_carga,
            self.marca,
            self.numero_serie,
            self.quantidade,
            self.id
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para excluir empilhadeira
    @staticmethod
    def excluir(id):
        conexao = Database()
        cursor = conexao.cursor()

        sql = "DELETE FROM empilhadeira WHERE id = %s"
        cursor.execute(sql, (id,))
        conexao.commit()

        cursor.close()
        conexao.close()

    #metodo para atualizar a quantidade de empilhadeira
    @staticmethod
    def atualizar_quantidade(id, nova_quantidade):
        conexao = Database()
        cursor = conexao.cursor()

        sql = "UPDATE empilhadeira SET quantidade = %s WHERE id = %s"
        cursor.execute(sql, (nova_quantidade, id))
        conexao.commit()

        cursor.close()
        conexao.close()
        return Empilhadeira
