#imports

from core.conexao import Database
from core.validar import Validador

#classe que representa um fornecedor no sistema
class Fornecedor:
    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome=None, cnpj=None, email=None, senha =None, id=None):
        #atribui os valores aos objetos
        self.id = id
        self.nome = nome
        self.cnpj = cnpj
        self.email = email
        self.senha= senha

    #cadastro do fornecedor
    def insert(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO fornecedor
        (nome, cnpj, email, senha)
        VALUES (%s, %s, %s, %s)
        """
        valores = (
            self.nome,
            self.cnpj,
            self.email,
            self.senha
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()
    
    #valida os dados do fornecedor
    def validate(self):

        #lista de possiveis erros
        erros = [
        Validador.required(self.nome, "nome"),
        Validador.required(self.cnpj, "CNPJ"),
        Validador.required(self.email, "email"),
        Validador.required(self.senha, "senha"),
        ]       
        #retorna os erros
        return [erro for erro in erros if erro]

    #metodo para listar fornecedor
    @staticmethod
    def find_all():
        #conexao com o banco
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM fornecedor ORDER BY nome"
        cursor.execute(sql)
        resultado = cursor.fetchall()
        return resultado

        cursor.close()
        conexao.close()
        return Fornecedor
    
    #metodo para buscar o id do fornecedor
    @staticmethod
    def find_by_id(id):
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM fornecedor WHERE id = %s"
        cursor.execute(sql, (id,))
        resultado = cursor.fetchone()
        return resultado

        cursor.close()
        conexao.close()
        return Fornecedor

    #metodo para atualizar fornecedor
    def update(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        UPDATE fornecedor
        SET nome = %s,
            cnpj = %s,
            email = %s,
            senha = %s
        WHERE id = %s
        """
        valores = (
            self.nome,
            self.cnpj,
            self.email,
            self.senha,
            self.id
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para excluir fornecedor
    @staticmethod
    def delete(id):
        conexao = Database()
        cursor = conexao.cursor()

        sql = "DELETE FROM fornecedor WHERE id = %s"
        cursor.execute(sql, (id,))
        conexao.commit()

        cursor.close()
        conexao.close()

    