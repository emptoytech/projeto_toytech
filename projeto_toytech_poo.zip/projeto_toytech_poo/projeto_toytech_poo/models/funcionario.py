#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa um funcionario no sistema
class Funcionario(Crud):
    table = "funcionario"
    #lista de campos da tabela
    fields = [
        "nome",
        "cpf",
        "email",
        "senha",
        "telefone",
        "cargo"
    ]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome, cpf, email, senha,
                 telefone, cargo):
        #atribui os valores aos objetos
        self.nome = nome
        self.cpf = cpf
        self.email = email
        self.senha = senha
        self.telefone = telefone
        self.cargo = cargo

    #cadastro do funcionario
    def insert(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO funcionario
        (nome, cpf, email, senha, telefone, cargo)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        valores = (
            self.nome,
            self.cpf,
            self.email,
            self.senha,
            self.telefone,
            self.cargo
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #valida os dados do funcionario
    def validate(self):
        #lista de possiveis erros
        erros = [
         Validador.required(self.nome, "nome"),
         Validador.non_negative(self.cpf, "CPF"),
         Validador.non_negative(self.email, "email"),
         Validador.non_negative(self.senha, "senha"),
         Validador.non_negative(self.telefone, "telefone"),
         Validador.non_negative(self.cargo, "cargo")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]

    #retorna funcionarios na ordem alfabética de cargos
    @classmethod
    def low_stock(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM funcionario ORDER BY cargo"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()


    #metodo para atualizar o funcionario
    def update(self):
        #conexao com o banco
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        UPDATE funcionario
        SET nome = %s,
            cpf = %s,
            email = %s,
            senha = %s,
            telefone = %s,
            cargo = %s
        WHERE id = %s
        """
        valores = (
            self.nome,
            self.cpf,
            self.email,
            self.senha,
            self.telefone,
            self.cargo,
            self.id
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para excluir funcionario
    @classmethod
    def safe_delete(cls, id):
        Funcionario = cls.find_by_id(id)
        if not Funcionario:
            raise ValueError("Funcionario não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o funcionario.")
        cls.delete(id)
