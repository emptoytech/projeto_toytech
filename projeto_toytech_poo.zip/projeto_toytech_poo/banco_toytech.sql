CREATE DATABASE Toytech_bd;
USE Toytech_bd;


CREATE TABLE produto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255),
    fornecedor_nome VARCHAR(100),
    localizacao_produto INT NOT NULL,
    estoque_minimo INT NOT NULL DEFAULT 15,
    imagem LONGTEXT,
    preco DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_produto_fornecedor FOREIGN KEY (fornecedor_nome) REFERENCES fornecedor(nome),
    CONSTRAINT fk_produto_localizacao FOREIGN KEY (localizacao_produto) REFERENCES localizacao(id)
);


CREATE TABLE estoque (
    produto_id INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_produto_id FOREIGN KEY (produto_id) REFERENCES fornecedor(id)
);


CREATE TABLE solicitacao_saida (
    id INT AUTO_INCREMENT PRIMARY KEY,
    observacao VARCHAR(255),
    data_solicitacao_saida DATETIME NOT NULL,
    funcionario_id INT NOT NULL,
    solicitador_id INT NOT NULL,
    CONSTRAINT fk_funcionario FOREIGN KEY (funcionario_id) REFERENCES funcionario(id),
    CONSTRAINT fk_solicitante FOREIGN KEY (solicitador_id) REFERENCES solicitador(id)
);


CREATE TABLE solicitacao_entrada (
    id INT AUTO_INCREMENT PRIMARY KEY,
    observacao VARCHAR(255),
    data_solicitacao_entrada DATETIME NOT NULL,
    fornecedor_id INT NOT NULL,
    fornecedor_cnpj VARCHAR(14),
    funcionario_id INT NOT NULL,
    CONSTRAINT fk_solicitacao_fornecedor FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(id),
    CONSTRAINT fk_solicitacao_fornecedor_cnpj FOREIGN KEY (fornecedor_cnpj) REFERENCES fornecedor(cnpj),
    CONSTRAINT fk_funcionario FOREIGN KEY (funcionario_id) REFERENCES funcionario(id)
);


CREATE TABLE item_solicitacao_entrada (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_produto VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL,
    preco_produto DECIMAL(10,2) NOT NULL DEFAULT 0,
    imagem LONGTEXT
);


CREATE TABLE item_solicitacao_saida (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_produto VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL,
    preco_produto DECIMAL(10,2) NOT NULL DEFAULT 0
);


CREATE TABLE movimentacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    tipo_movimentacao VARCHAR(10) NOT NULL,
    quantidade INT NOT NULL,
    data_movimentacao DATETIME NOT NULL,
    CONSTRAINT fk_movimentacao_produto FOREIGN KEY (produto_id) REFERENCES produto(id),
    CONSTRAINT fk_movimentacao_funcionario FOREIGN KEY (funcionario_id) REFERENCES funcionario(id)
);


CREATE TABLE empilhadeira (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255),
    capacidade_carga VARCHAR(10),
    num_serie VARCHAR(6),
    marca VARCHAR(100),
    quantidade INT NOT NULL DEFAULT 0
);


CREATE TABLE fornecedor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cnpj VARCHAR(14),
    telefone VARCHAR(20)
);


CREATE TABLE funcionario (
    id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    email VARCHAR(50),
    senha VARCHAR(20),
    telefone VARCHAR(20) NOT NULL,
    cargo VARCHAR(30) NOT NULL
);


CREATE TABLE solicitador (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cnpj VARCHAR(14),
    senha VARCHAR(20),
    telefone VARCHAR(20)
);


CREATE TABLE localizacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conteudo VARCHAR(400) NOT NULL,
    localizacao_estoque INT NOT NULL,
    localizacao_produto INT NOT NULL,
    CONSTRAINT fk_produto_localizacao FOREIGN KEY (localizacao_produto) REFERENCES produto(id),
    CONSTRAINT fk_estoque_localizacao FOREIGN KEY (localizacao_estoque) REFERENCES estoque(id)
);


CREATE TABLE sensor (
  id INT AUTO_INCREMENT PRIMARY KEY,
  modelo_sensor VARCHAR(45),
  descricao_base LONGTEXT,
  descricao_funcao_sensor VARCHAR(300),
  altura_sensor FLOAT,
  largura_sensor FLOAT
);
