import json
import logging

import paho.mqtt.client as mqtt

from config import MQTT_BROKER, MQTT_PORT, MQTT_TOPIC_RECONHECIMENTO
from core.reconhecimento import registrar_reconhecimento

logger = logging.getLogger("toytech.mqtt")


def _ao_conectar(cliente, usuario, flags, codigo, propriedades):
    if int(codigo) == 0:
        logger.info("Conectado ao broker MQTT %s:%s", MQTT_BROKER, MQTT_PORT)
        cliente.subscribe(MQTT_TOPIC_RECONHECIMENTO, qos=1)
        logger.info("Inscrito no tópico %s", MQTT_TOPIC_RECONHECIMENTO)
    else:
        logger.error("Falha ao conectar ao MQTT. Código: %s", codigo)


def _ao_receber_mensagem(cliente, usuario, mensagem):
    try:
        dados = json.loads(mensagem.payload.decode("utf-8"))
        resultado = registrar_reconhecimento(dados)

        if resultado.get("duplicado"):
            logger.info("Evento MQTT duplicado ignorado: %s", dados.get("evento_id"))
        elif resultado.get("registrado"):
            logger.info(
                "Produto reconhecido: %s (confiança %.2f)",
                resultado["produto"],
                resultado["confianca"]
            )
    except Exception:
        logger.exception("Não foi possível processar a mensagem MQTT recebida.")


def iniciar_mqtt():
    """Inicia o consumidor MQTT em uma thread sem bloquear o Flask."""
    cliente = mqtt.Client(
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
        client_id="toytech_backend"
    )
    cliente.on_connect = _ao_conectar
    cliente.on_message = _ao_receber_mensagem
    cliente.reconnect_delay_set(min_delay=1, max_delay=30)

    # connect_async permite que o Flask suba mesmo se o Mosquitto ainda estiver iniciando.
    cliente.connect_async(MQTT_BROKER, MQTT_PORT, keepalive=60)
    cliente.loop_start()
    return cliente
