from datetime import datetime

from core.conexao import Database
from config import MAPA_CLASSES_PRODUTOS, MQTT_CONFIDENCE_MIN


def registrar_reconhecimento(dados):
    """Registra um objeto reconhecido e incrementa seu estoque uma única vez."""
    classe = str(dados.get("classe", "")).strip()
    evento_id = str(dados.get("evento_id", "")).strip()

    try:
        confianca = float(dados.get("confianca", 0))
    except (TypeError, ValueError):
        raise ValueError("Confiança inválida recebida pelo MQTT.")

    if not classe:
        raise ValueError("A classe recebida está vazia.")
    if not evento_id or len(evento_id) > 64:
        raise ValueError("Identificador do evento ausente ou inválido.")
    if confianca < MQTT_CONFIDENCE_MIN or confianca > 1:
        raise ValueError("Reconhecimento abaixo da confiança mínima configurada.")

    nome_produto = MAPA_CLASSES_PRODUTOS.get(classe)
    if not nome_produto:
        raise ValueError(f"A classe '{classe}' não está mapeada em MAPA_CLASSES_PRODUTOS.")

    conexao = Database.connect()
    cursor = conexao.cursor(dictionary=True)

    try:
        cursor.execute(
            "SELECT id FROM produto WHERE LOWER(TRIM(nome)) = LOWER(TRIM(%s)) LIMIT 1",
            (nome_produto,)
        )
        produto = cursor.fetchone()

        if not produto:
            raise ValueError(
                f"Não existe produto cadastrado com o nome '{nome_produto}' "
                f"(classe recebida: '{classe}'). Confira MAPA_CLASSES_PRODUTOS."
            )

        produto_id = produto["id"]

        # Confirma e bloqueia a linha do estoque até a transação terminar.
        cursor.execute(
            "SELECT estoque_id FROM estoque WHERE produto_id = %s FOR UPDATE",
            (produto_id,)
        )
        estoque = cursor.fetchone()
        if not estoque:
            raise ValueError(
                f"O produto '{nome_produto}' não possui registro na tabela estoque."
            )

        # O evento_id é UNIQUE no banco: mensagens MQTT repetidas não contam duas vezes.
        cursor.execute(
            """
            INSERT INTO reconhecimento (evento_id, produto_id, confianca)
            VALUES (%s, %s, %s)
            """,
            (evento_id, produto_id, confianca)
        )

        cursor.execute(
            """
            UPDATE estoque
            SET produto_quantidade = produto_quantidade + 1
            WHERE produto_id = %s
            """,
            (produto_id,)
        )

        conexao.commit()
        return {
            "registrado": True,
            "duplicado": False,
            "produto_id": produto_id,
            "produto": nome_produto,
            "classe": classe,
            "confianca": confianca
        }

    except Exception as erro:
        conexao.rollback()
        # O QoS 1 do MQTT pode reenviar uma mensagem. Se o evento já existe,
        # tratamos como duplicado, sem incrementar o estoque novamente.
        if getattr(erro, "errno", None) == 1062:
            return {"registrado": False, "duplicado": True, "evento_id": evento_id}
        raise
    finally:
        cursor.close()
        conexao.close()


def obter_resumo_reconhecimento():
    """Retorna contagem acumulada dos objetos reconhecidos pela câmera."""
    conexao = Database.connect()
    cursor = conexao.cursor(dictionary=True)

    try:
        cursor.execute("SELECT COUNT(*) AS total FROM reconhecimento")
        total = cursor.fetchone()["total"]

        cursor.execute(
            """
            SELECT p.nome, COUNT(r.id) AS quantidade
            FROM produto p
            LEFT JOIN reconhecimento r ON r.produto_id = p.id
            GROUP BY p.id, p.nome
            ORDER BY p.nome
            """
        )
        produtos = cursor.fetchall()

        cursor.execute(
            """
            SELECT p.nome, r.reconhecido_em
            FROM reconhecimento r
            INNER JOIN produto p ON p.id = r.produto_id
            ORDER BY r.reconhecido_em DESC, r.id DESC
            LIMIT 1
            """
        )
        ultimo = cursor.fetchone()

        if ultimo and isinstance(ultimo["reconhecido_em"], datetime):
            ultimo["reconhecido_em"] = ultimo["reconhecido_em"].isoformat(sep=" ")

        return {
            "total": int(total or 0),
            "produtos": [
                {"nome": item["nome"], "quantidade": int(item["quantidade"] or 0)}
                for item in produtos
            ],
            "ultimo": ultimo
        }
    finally:
        cursor.close()
        conexao.close()
