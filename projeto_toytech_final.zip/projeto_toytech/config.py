DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "123456",
    "database": "Toytech_bd",
    "auth_plugin": "mysql_native_password"
}


# Configurações da integração de reconhecimento por MQTT
MQTT_BROKER = "127.0.0.1"
MQTT_PORT = 1883
MQTT_TOPIC_RECONHECIMENTO = "toytech/reconhecimento"
MQTT_CONFIDENCE_MIN = 0.80

# Relaciona o nome da classe do Teachable Machine ao nome EXATO do produto no MySQL.
# Ajuste o valor à direita caso o produto esteja cadastrado com outro nome.
MAPA_CLASSES_PRODUTOS = {
    "Azul": "Azul",
    "Estojo": "Estojo"
}
