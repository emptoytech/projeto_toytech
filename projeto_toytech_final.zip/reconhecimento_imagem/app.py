import json
import cv2
import numpy as np
import paho.mqtt.client as mqtt
from tf_keras.models import load_model
import time

# =====================================================
# 1. CONFIGURACOES MQTT - HIVEMQ CLOUD
# =====================================================
MQTT_BROKER = "b1600c60a35c4520b32b9507d0b47b02.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USER = "IOT-SENAI"
MQTT_PASSWORD = "12345678"
MQTT_CLIENT_ID = "pc-camera-01"
MQTT_TOPIC = "sensores/camera"
MQTT_TOPIC_STATUS = "sensores/camera/status"

def conectar_mqtt():
    print("=================================")
    print("CONECTANDO AO MQTT (HIVEMQ CLOUD)")
    print("=================================")
    try:
        try:
            client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=MQTT_CLIENT_ID)
        except AttributeError:
            client = mqtt.Client(client_id=MQTT_CLIENT_ID)

        client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
        client.tls_set()

        # Avisa o HiveMQ para publicar "offline" se o script cair de repente
        client.will_set(MQTT_TOPIC_STATUS, payload="offline", qos=1, retain=True)

        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=15)
        client.loop_start()

        # Avisa imediatamente que a camera entrou no ar
        client.publish(MQTT_TOPIC_STATUS, payload="online", qos=1, retain=True)
        print("MQTT CONECTADO COM SUCESSO!\n")
        return client
    except Exception as erro:
        print(f"ERRO NA CONEXAO MQTT: {erro}\n")
        return None


def publicar(client, dados):
    if client is None:
        return
    try:
        mensagem = json.dumps(dados)
        client.publish(MQTT_TOPIC, mensagem)
        print(f"[MQTT] Topico: {MQTT_TOPIC} | Mensagem: {mensagem}")
    except Exception as erro:
        print(f"[MQTT] Erro ao publicar: {erro}")


# =====================================================
# 2. INICIALIZACAO DO MODELO E WEBCAM FULL HD
# =====================================================
mqtt_client = conectar_mqtt()

model = load_model('keras_model.h5', compile=False)
data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
classes = ['', 'Azul', 'Estojo']

# Use 0 para PC de mesa ou 1 para notebook com webcam externa
INDICE_CAMERA = 1
cap = cv2.VideoCapture(INDICE_CAMERA, cv2.CAP_DSHOW)

# Configura codec MJPG e resolucao Full HD (1920x1080)
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

cv2.namedWindow('Video', cv2.WINDOW_NORMAL)
cv2.resizeWindow('Video', 1280, 720)

# =====================================================
# 3. PARAMETROS DE CONFIANCA E ESTABILIDADE
# =====================================================
confidence_threshold = 0.8

# Quantos frames seguidos o mesmo objeto precisa aparecer para confirmar o envio.
# A ~30 FPS: 10 frames ≈ 0,33s | 15 frames ≈ 0,5s | 30 frames ≈ 1,0s
FRAMES_ESTABILIDADE = 10

ultimo_objeto_enviado = None
candidato_atual = None
contador_frames = 0
ultimo_heartbeat = 0

while True:
    ret, frame = cap.read()
    if not ret:
        print("Erro: Nao foi possivel capturar frame da webcam.")
        break

    # Recorte central quadrado (1080x1080) para manter a proporcao 1:1 do modelo
    altura, largura, _ = frame.shape
    inicio_x = (largura - altura) // 2
    frame_quadrado = frame[:, inicio_x:inicio_x + altura]

    # Guia visual da area analisada pela IA
    cv2.rectangle(frame, (inicio_x, 0), (inicio_x + altura, altura), (255, 255, 0), 2)

    # Pre-processamento (RGB + 224x224 + Normalizacao)
    img_rgb = cv2.cvtColor(frame_quadrado, cv2.COLOR_BGR2RGB)
    imgS = cv2.resize(img_rgb, (224, 224))
    image_array = np.asarray(imgS)
    normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
    data[0] = normalized_image_array

    # Inferencia
    prediction = model.predict(data, verbose=0)
    confidence = float(np.max(prediction))
    indexVal = int(np.argmax(prediction))

    if confidence > confidence_threshold and classes[indexVal] != '':
        objeto_atual = str(classes[indexVal])
    else:
        objeto_atual = "Nenhum"

    # =====================================================
    # 4. FILTRO DE ESTABILIDADE (DEBOUNCE POR FRAMES)
    # =====================================================
    if objeto_atual == candidato_atual:
        contador_frames = min(contador_frames + 1, FRAMES_ESTABILIDADE)
    else:
        candidato_atual = objeto_atual
        contador_frames = 1

    # Feedback visual na tela (amarelo enquanto valida, verde quando confirmado)
    if objeto_atual != "Nenhum":
        if contador_frames < FRAMES_ESTABILIDADE and objeto_atual != ultimo_objeto_enviado:
            texto_tela = f"{objeto_atual} ({contador_frames}/{FRAMES_ESTABILIDADE})"
            cor_texto = (0, 255, 255)  # Amarelo: estabilizando
        else:
            texto_tela = f"{objeto_atual} ({confidence * 100:.1f}%)"
            cor_texto = (0, 255, 0)    # Verde: confirmado
        cv2.putText(frame, texto_tela, (inicio_x + 30, 70), cv2.FONT_HERSHEY_COMPLEX, 1.6, cor_texto, 3)

    # Publica no MQTT somente apos atingir os frames seguidos de estabilidade
    if contador_frames >= FRAMES_ESTABILIDADE and candidato_atual != ultimo_objeto_enviado:
        payload = {
            "objeto": candidato_atual,
            "confianca": round(confidence * 100, 1) if candidato_atual != "Nenhum" else 0.0
        }
        publicar(mqtt_client, payload)
        ultimo_objeto_enviado = candidato_atual

    # Envia um pulso a cada 5 segundos para o dashboard saber que a camera esta viva
    if time.time() - ultimo_heartbeat >= 5:
        publicar(mqtt_client, {"tipo": "heartbeat"})
        ultimo_heartbeat = time.time()
        
    cv2.imshow('Video', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
if mqtt_client is not None:
    mqtt_client.publish(MQTT_TOPIC_STATUS, payload="offline", qos=1, retain=True)
    time.sleep(0.2)
    mqtt_client.loop_stop()
    mqtt_client.disconnect()