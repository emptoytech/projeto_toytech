from core.crud import Crud
from core.conexao import Database
from core.validar import Validador
from core.security import gerar_hash_senha, verificar_senha, TODOS_OS_CARGOS

class Funcionario(Crud):
    table = "funcionario"
    fields = ["id", "nome", "cpf", "email", "senha", "telefone", "cargo"]

    def __init__(self, nome, cpf, email, senha, telefone, cargo, id=None):
        self.id = id
        self.nome = nome
        self.cpf = cpf
        self.email = email
        self.senha = senha
        self.telefone = telefone
        self.cargo = cargo

    def validate(self):
        erros = [
            Validador.required(self.nome, "nome"),
            Validador.required(self.telefone, "telefone"),
            Validador.required(self.cpf, "cpf"),
            Validador.required(self.email, "email"),
            Validador.count_to_11(self.cpf, "cpf"),
            Validador.count_to_11(self.telefone, "telefone"),
            Validador.have_scaracter(self.email, "email"),
            Validador.required(self.cargo, "cargo"),
            Validador.not_have_number(self.cargo, "cargo"),
            Validador.have_number(self.telefone, "telefone"),
            Validador.required(self.senha, "senha"),
            Validador.count_to_8(self.senha, "senha"),
            Validador.have_upper(self.nome, "nome"),
            Validador.required(self.cargo, "cargo")
        ]

        # Garante que o cargo digitado pertence à lista de cargos válidos
        cargos_validos_lower = [c.lower() for c in TODOS_OS_CARGOS]
        if self.cargo and self.cargo.strip().lower() not in cargos_validos_lower:
            erros.append(f"Cargo inválido. Escolha um dos seguintes: {', '.join(TODOS_OS_CARGOS)}")

        return [erro for erro in erros if erro]

    @classmethod
    def find_by_email(cls, email):
        conexao = Database.connect()
        # Garante que o retorno seja um dicionário
        cursor = conexao.cursor(dictionary=True) 

        sql = "SELECT * FROM funcionario WHERE email = %s"
        cursor.execute(sql, (email,))
    
        # ATENÇÃO: Use fetchone() para retornar um dicionário único, NÃO fetchall()
        funcionario = cursor.fetchone()

        cursor.close()
        conexao.close()
        return funcionario

    @classmethod
    def autenticar(cls, email, senha):
        funcionario = cls.find_by_email(email)
        if funcionario and verificar_senha(senha, funcionario["senha"]):
            return funcionario
        return None

    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        # Criptografa a senha antes da inserção
        senha_hash = gerar_hash_senha(self.senha)

        sql = """
        INSERT INTO funcionario
        (nome, cpf, email, senha, telefone, cargo)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        valores = (
            self.nome,
            self.cpf,
            self.email,
            senha_hash,
            self.telefone,
            self.cargo
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    @classmethod
    def update(cls, nome, cpf, email, senha, telefone, cargo, id, connection=None):
        conexao = Database.connect() if connection is None else connection
        cursor = conexao.cursor()
        try:
            # Garante que, se uma nova senha for informada, ela seja criptografada
            if senha and not senha.startswith("$2b$"):
                senha = gerar_hash_senha(senha)

            sql = "UPDATE funcionario SET nome = %s, cpf = %s, email = %s, senha = %s, telefone = %s, cargo = %s WHERE id = %s"
            cursor.execute(sql, (nome, cpf, email, senha, telefone, cargo, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()