import requests
import urllib.parse

class InvertextoAPI:
    def __init__(self, token):
        self.token = token
        self.timeout = 5  # Limite de espera em segundos para não travar o sistema

    def validar_cpf(self, cpf):
        url = "https://api.invertexto.com/v1/validator"
        params = {"token": self.token, "value": cpf, "type": "cpf"}

        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            if response.status_code == 200:
                data = response.json()
                return data.get("valid", False)
        except requests.exceptions.RequestException as err:
            print(f"[API Error] Falha ao validar CPF: {err}")
        
        # Em caso de erro na API/Rede, permite a passagem ou trata conforme a regra
        return True 

    def validar_cnpj(self, cnpj):
        url = "https://api.invertexto.com/v1/validator"
        params = {"token": self.token, "value": cnpj, "type": "cnpj"}

        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            if response.status_code == 200:
                data = response.json()
                return data.get("valid", False)
        except requests.exceptions.RequestException as err:
            print(f"[API Error] Falha ao validar CNPJ: {err}")
            
        return True

    def validar_email(self, email):
        base_url = "https://api.invertexto.com/v1/email-validator"
        email_encoded = urllib.parse.quote(email)
        url = f"{base_url}/{email_encoded}"
        params = {"token": self.token}

        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            if response.status_code == 200:
                data = response.json()
                # Verifica se é um e-mail válido e se não é temporário (disposable)
                is_valid = data.get("valid", False)
                is_disposable = data.get("disposable", False)
                return is_valid and not is_disposable
        except requests.exceptions.RequestException as err:
            print(f"[API Error] Falha ao validar E-mail: {err}")
            
        return True