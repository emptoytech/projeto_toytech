from functools import wraps
from flask import session, redirect, url_for, flash, request
import bcrypt 

def gerar_hash_senha(senha):
    """
    Recebe uma senha em texto puro e retorna a senha criptografada.
    """
    senha_hash = bcrypt.hashpw(
        senha.encode("utf-8"),
        bcrypt.gensalt()
    )

    return senha_hash.decode("utf-8")


def verificar_senha(senha_digitada, senha_hash_banco):
    """
    Compara a senha digitada com a senha criptografada salva no banco.
    """
    return bcrypt.checkpw(
        senha_digitada.encode("utf-8"),
        senha_hash_banco.encode("utf-8")
    )


def login_obrigatorio(funcao):
    """
    Decorador para proteger rotas que exigem login.
    """
    @wraps(funcao)
    def wrapper(*args, **kwargs):
        if "funcionario_id" not in session:
            flash("Faça login para acessar o sistema.", "warning")
            return redirect(url_for("login"))

        return funcao(*args, **kwargs)

    return wrapper

CARGO_ADMIN = "Administrador"
CARGO_GERENTE = "Gerente"
CARGO_ESTOQUISTA = "Estoquista"
CARGO_OPERADOR = "Operador"

# Agrupamentos para facilitar a aplicação nas rotas
TODOS_OS_CARGOS = [CARGO_ADMIN, CARGO_GERENTE, CARGO_ESTOQUISTA, CARGO_OPERADOR]
APENAS_GESTAO = [CARGO_ADMIN, CARGO_GERENTE]
GESTAO_E_ESTOQUE = [CARGO_ADMIN, CARGO_GERENTE, CARGO_ESTOQUISTA]

def cargos_permitidos(*cargos_autorizados):
    """
    Decorador flexível que aceita cargos individuais ou listas de cargos.
    """
    def decorador(funcao):
        @wraps(funcao)
        def wrapper(*args, **kwargs):
            if "funcionario_id" not in session:
                flash("Faça login para acessar o sistema.", "warning")
                return redirect(url_for("login"))

            cargo_usuario = session.get("funcionario_cargo", "").strip().lower()

            # Processa e unifica a lista de cargos permitidos
            cargos_flat = []
            for item in cargos_autorizados:
                if isinstance(item, (list, tuple)):
                    cargos_flat.extend([str(c).strip().lower() for c in item])
                else:
                    cargos_flat.append(str(item).strip().lower())

            # Bloqueia se o cargo logado não estiver na lista
            if cargo_usuario not in cargos_flat:
                flash("Acesso negado: seu cargo não tem permissão para realizar esta ação.", "danger")
                return redirect(request.referrer or url_for("dashboard"))

            return funcao(*args, **kwargs)
        return wrapper
    return decorador