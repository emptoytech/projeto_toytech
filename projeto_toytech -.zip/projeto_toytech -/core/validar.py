import re
import os
from core.validar_externo import InvertextoAPI

INVERTEXTO_TOKEN = os.getenv("INVERTEXTO_TOKEN", "29106|aaG9CDklccxUVD6suZuOUo4v1haMy1Ap")
api_invertexto = InvertextoAPI(INVERTEXTO_TOKEN)

class Validador:
    @staticmethod
    def required(value, field_name):
        if value is None or str(value).strip() == "":
            return f"O campo {field_name} é obrigatório."
        return None

    @staticmethod
    def non_negative(value, field_name):
        try:
            if float(value) < 0:
                return f"O campo {field_name} não pode ser negativo."
        except (TypeError, ValueError):
            return f"O campo {field_name} deve ser numérico."
        return None

    @staticmethod
    def positive(value, field_name):
        try:
            if int(value) >= 0:
                return f"O campo {field_name} deve ser maior que zero."
        except (TypeError, ValueError):
            return f"O campo {field_name} deve ser numérico."
        return None

    @staticmethod
    def count_to_8(value, field_name):
        str_valor = str(value).strip()
        if len(str_valor) != 8 :
            return f"O campo {field_name} é obrigatório que tenha exatamente 8 caracteres"
        return None

    @staticmethod
    def count_to_9(value, field_name):
        str_valor = str(value).strip()
        if len(str_valor) != 9 :
            return f"O campo {field_name} é obrigatório que tenha exatamente 9 caracteres"
        return None

    @staticmethod
    def count_to_11(value, field_name):
        str_valor = str(value).strip()
        if len(str_valor) != 11 :
            return f"O campo {field_name} é obrigatório que tenha exatamente 11 caracteres"
        return None
   
    @staticmethod
    def count_to_14(value, field_name):
        str_valor = str(value.strip())
        if len(str_valor) != 14 :
            return f"O campo {field_name} é obrigatório que tenha exatamente 14 caracteres"
        return None
   
    @staticmethod
    def have_number(value, field_name):
        if not str(value).isdigit():
            return f"O campo {field_name} deve conter apenas números."
        return None  
   
    @staticmethod
    def have_scaracter(value, field_name):
        for caractere in value:
            if not caractere.isalnum():
                return None
        return f"O campo {field_name} deve ter caracteres especiais."

    @staticmethod
    def not_have_scaracter(value, field_name):
        for caractere in value:
            if caractere.isalnum():
                return f"O campo {field_name} não deve ter caracteres especiais."
        return None

   
    @staticmethod
    def not_have_number(value, field_name):
        for caractere in value:
            if caractere.isdigit():
                return f"O campo {field_name} não deve ter caracteres numéricos."
        return None

    @staticmethod
    def have_upper(value, field_name):
        for caractere in value:
            if caractere.isupper():
                return None
        return f"O campo {field_name} deve ter letras maiúsculas."
   
    @staticmethod
    def not_have_upper(value, field_name):
        for caractere in value:
            if caractere.isupper():
                return f"O campo {field_name} não deve ter letras maiúsculas."
        return None

    @staticmethod
    def price(value, field_name):
        if value is None:
            return f"O campo {field_name} é obrigatório."

        if not isinstance(value, (int, float)):
            return f"O campo {field_name} deve ser numérico."

        if value <= 0:
            return f"O campo {field_name} deve ser maior que zero."
        return None

    @staticmethod
    def cpf_api(cpf, campo="cpf"):
        if cpf and not api_invertexto.validar_cpf(cpf):
            return f"O {campo} informado é inválido."
        return None

    @staticmethod
    def cnpj_api(cnpj, campo="cnpj"):
        if cnpj and not api_invertexto.validar_cnpj(cnpj):
            return f"O {campo} informado é inválido."
        return None

    @staticmethod
    def email_api(email, campo="email"):
        if email and not api_invertexto.validar_email(email):
            return f"O {campo} informado é inválido ou temporário."
        return None

    @staticmethod
    def telefone_local(telefone, campo="Telefone"):
        if not telefone:
            return None
        apenas_numeros = re.sub(r'\D', '', str(telefone))
        if len(apenas_numeros) not in [11]:
            return f"O {campo} deve conter DDD + número (11 dígitos)."
        ddd = int(apenas_numeros[:2])
        if ddd < 11 or ddd > 99:
            return f"O DDD do {campo} é inválido."
        if len(apenas_numeros) == 11 and apenas_numeros[2] != '9':
            return f"O número de celular no campo {campo} deve começar com 9."
        return None