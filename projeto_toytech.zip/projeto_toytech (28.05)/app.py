from flask import Flask, render_template, request, redirect, url_for, flash
from models.produto import Produto
from models.fornecedor import Fornecedor
from models.funcionario import Funcionario
from models.sensor import Sensor
from models.localizacao import Localizacao
from models.solicitador import Solicitador
from models.solicitacao_entrada import SolicitacaoEntrada
from models.solicitacao_saida import SolicitacaoSaida
from models.item_solicitacao_entrada import ItemSolicitacaoEntrada
from models.item_solicitacao_saida import ItemSolicitacaoSaida
from models.estoque import Estoque

app = Flask(__name__)
app.secret_key = "chave_secreta"


def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default

def get_produto_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "descricao": (request.form.get("descricao", "").strip()),
        "fornecedor": (request.form.get("fornecedor", "").strip()),
        "localizacao_produto": (request.form.get("localizacao_produto", "").strip()),
        "imagem": (request.form.get("imagem","").strip()),
        "preco": (request.form.get("preco",0))
    }
def get_fornecedor_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone": request.form.get("telefone","").strip()
    }

def get_funcionario_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cpf": request.form.get("cpf", "").strip(),
        "email": request.form.get("email", "").strip(),
        "senha": request.form.get("senha","").strip(),
        "telefone": request.form.get("telefone","").strip(),
        "cargo": request.form.get("cargo","").strip()
    }


def get_solicitador_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "senha": request.form.get("senha","").strip(),
        "telefone":request.form.get("telefone","").strip()
    }

def get_sensor_form():
    return {
        "modelo_sensor": request.form.get("modelo_sensor", "").strip(),
        "descricao_funcao_sensor": request.form.get("descricao_funcao_sensor", "").strip(),
        "fornecedor_id": request.form.get("fornecedor_id","").strip(),
        "altura_sensor": request.form.get("altura_sensor","").strip(),
        "largura_sensor": request.form.get("largura_sensor","").strip(),
        "tipo": request.form.get("tipo","").strip(),

    }

def get_localizacao_form():
    return {
        "rua": request.form.get("rua","").strip(),
        "prateleira": request.form.get("prateleira", "").strip(),
        "andar": request.form.get("andar","").strip()

    }

def get_solicitacao_entrada_form():
    return {
        "id_operacao_e": request.form.get("id_operacao_e", "").strip(),
        "data_solicitacao_entrada": request.form.get("data_solicitacao_entrada", "").strip(),
        "funcionario_id": request.form.get("funcionario_id","").strip(),
        "fornecedor_id": request.form.get("fornecedor_id","").strip(),
        "observacao": request.form.get("observacao","").strip()
        }

def get_item_solicitacao_entrada_form():
    return {
        "produto_id": request.form.get("produto_id", "").strip(),
        "produto_nome": request.form.get("produto_nome", "").strip(),
        "produto_quantidade": request.form.get("produto_quantidade","").strip(),
        "produto_preco": request.form.get("produto_preco","").strip()
    }

def get_solicitacao_saida_form():
    return {
        "id_operacao": request.form.get("id_operacao", "").strip(),
        "data_solicitacao_saida": request.form.get("data", "").strip(),
        "observacao": request.form.get("observacao","").strip(),
        "funcionario_id": request.form.get("funcionario_id","").strip(),
        "solicitador_id": request.form.get("solicitador_id","").strip()
    }

def get_item_solicitacao_saida_form():
    return {
        "produto_id": request.form.get("produto_id", "").strip(),
        "produto_nome": request.form.get("produto_nome", "").strip(),
        "produto_quantidade": request.form.get("produto_quantidade","").strip(),
        "produto_preco": request.form.get("produto_preco","").strip()
    }

'''@app.route("/", methods=["GET", "POST"])
def login():

    if request.method == "POST":
        email = request.form.get("email")
        senha = request.form.get("senha")

        funcionario = Funcionario.autenticar(email, senha)

        if funcionario:
            session["funcionario_id"] = funcionario["id"]
            session["funcionario_nome"] = funcionario["nome"]
            session["funcionario_cargo"] = funcionario["cargo"]
            flash("Login realizado com sucesso!", "success")
            return redirect(url_for("login"))
        flash("Email ou senha inválidos.", "danger")
    return render_template("loginbs.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Você saiu do sistema.", "info")
    return redirect(url_for("logout"))
'''

@app.route("/produto")
def produto():
    return render_template("lista_produto.html", produtos=Produto.find_by_name(order_by="nome"))

@app.route("/produto/novo", methods = ["GET"])
def novo_produto():
    return render_template("produto.html", produto=None)

@app.route("/produto/salvar", methods=["POST"])
def salvar_produto():
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("produto.html", produto=dados)

    try:
        produto.insert()
        flash("Produto cadastrado com sucesso.", "sucesso")
        return redirect(url_for("produto"))
    except Exception as e:
        flash(f"Erro ao cadastrar produto: {e}", "erro")
        return render_template("produto.html", produto=dados)

@app.route("/produto/listar/<int:id>", methods = ["GET"])
def listar_produto(id):
    produto = Produto.find_by_id(id)
    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produto"))
    return render_template("lista_produto.html", produto=produto)


@app.route("/produto/atualizar/<int:id>", methods=["POST"])
def atualizar_produto(id):
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("produto.html", produto=dados)

    try:
        if not produto.find_by_id(id):
            flash("Produto não encontrado.", "erro")
            return redirect(url_for("produto"))

        produto.update(id)
        flash("Produto atualizado com sucesso.", "sucesso")
        return redirect(url_for("produto"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar produto: {e}", "erro")
        return render_template("produto.html", produto=dados)

@app.route("/produto/excluir/<int:id>", methods = ["DELETE"])
def excluir_produto(id):
    try:
        produto.safe_delete(id)
        flash("Produto excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir produto: {e}", "erro")
    return redirect(url_for("produto"))

@app.route("/sensor")
def sensor():
    return render_template("lista_sensor.html", sensor=Sensor.find_by_name(order_by="modelo_sensor"))

@app.route("/sensor/novo", methods = ["GET"])
def novo_sensor():
    return render_template("sensor.html", sensor=None)

@app.route("/sensor/salvar", methods=["POST"])
def salvar_sensor():
    dados = get_sensor_form()
    sensor = Sensor(**dados)
    erros = sensor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("sensor.html", sensor=dados)

    try:
        sensor.insert()
        flash("O sensor foi cadastrado com sucesso.", "sucesso")
        return redirect(url_for("sensor"))
    except Exception as e:
        flash(f"Erro ao cadastrar o sensor: {e}", "erro")
        return render_template("sensor.html", sensor=dados)

@app.route("/sensor/listar/<int:id>", methods = ["GET"])
def listar_sensor(id):
    sensor = Sensor.find_by_id(id)
    if not sensor:
        flash("Sensor não encontrado.", "erro")
        return redirect(url_for("sensor"))
    return render_template("lista_sensor.html", sensor=sensor)

@app.route("/sensor/atualizar/<int:id>", methods=["POST"])
def atualizar_sensor(id):
    dados = get_sensor_form()
    sensor = Sensor(**dados)
    erros = sensor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("sensor.html", sensor=dados)
    try:
        if not sensor.find_by_id(id):
            flash("Sensor não encontrado.", "erro")
            return redirect(url_for("sensor"))

        sensor.update(id)
        flash("Sensor atualizado com sucesso.", "sucesso")
        return redirect(url_for("sensor"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar o sensor: {e}", "erro")
        return render_template("sensor.html", sensor=dados)

@app.route("/sensor/excluir/<int:id>", methods = ["DELETE"])
def excluir_sensor(id):
    try:
        sensor.delete(id)
        flash("Sensor foi excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir o sensor: {e}", "erro")
    return redirect(url_for("sensor"))

@app.route("/fornecedor")
def fornecedor():
    return render_template("lista_fornecedor.html", fornecedor=Fornecedor.find_by_name(order_by="nome"))

@app.route("/fornecedor/novo", methods = ["GET"])
def novo_fornecedor():
    return render_template("for.html", fornecedor=None)

@app.route("/fornecedor/<int:id>", methods = ["GET"])
def findbyid_fornecedor(id):
    fornecedor = Fornecedor.find_by_id(id)

    if not fornecedor:
        return {"erro": "Fornecedor não encontrado"}, 404
    return render_template("lista_fornecedor.html")
        
@app.route("/fornecedor/salvar", methods=["POST"])
def salvar_fornecedor():
    dados = get_fornecedor_form()
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("for.html", fornecedor=dados)

    try:
        fornecedor.insert()
        flash("Fornecedor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "erro")
        return render_template("for.html", fornecedor=dados)


@app.route("/fornecedor/atualizar/<int:id>", methods=["POST"])
def atualizar_fornecedor(id):
    dados = get_fornecedor_form()
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("for.html", fornecedor=dados)

    try:
        if not fornecedor.find_by_id(id):
            flash("Fornecedor não encontrado.", "erro")
            return redirect(url_for("fornecedor"))

        fornecedor.update(id)
        flash("Fornecedor atualizado com sucesso.", "sucesso")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar fornecedor: {e}", "erro")
        return render_template("for.html", fornecedor=dados)

@app.route("/fornecedor/excluir/<int:id>", methods = ["DELETE"])
def excluir_fornecedor(id):
    try:
        fornecedor.delete(id)
        flash("Fornecedor excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir fornecedor: {e}", "erro")
    return redirect(url_for("fornecedor"))

@app.route("/funcionario")
def funcionario():
    return render_template("lista_funcionario.html", funcionario=Funcionario.find_by_name(order_by="nome"))

@app.route("/funcionario/novo", methods = ["GET"])
def novo_funcionario():
    return render_template("fun.html", funcionario=None)

@app.route("/funcionario/<int:id>", methods = ["GET"])
def findbyid_funcionario(id):
    funcionario = Funcionario.find_by_id(id)

    if not funcionario:
        return {"erro": "Funcionario não encontrado"}, 404 
    return render_template("lista_funcionario.html")

@app.route("/funcionario/salvar", methods=["POST"])
def salvar_funcionario():
    dados = get_funcionario_form()
    funcionario = Funcionario(**dados)
    erros = funcionario.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("fun.html", funcionario=dados)

    try:
        funcionario.insert()
        flash("Funcionario cadastrado com sucesso.", "sucesso")
        return redirect(url_for("funcionario"))
    except Exception as e:
        flash(f"Erro ao cadastrar funcionario: {e}", "erro")
        return render_template("fun.html", funcionario=dados)

@app.route("/funcionario/listar/<int:id>", methods = ["GET"])
def listar_funcionario(id):
    funcionario = Funcionario.find_by_id(id)
    if not funcionario:
        flash("Funcionario não encontrado.", "erro")
        return redirect(url_for("funcionario"))
    return render_template("lista_funcionario.html", funcionario=funcionario)

@app.route("/funcionario/listar", methods = ["GET"])
def listar_cargo_funcionario(cargo):
    funcionario = Funcionario.find_by_cargo(cargo)
    if not funcionario:
        flash("Cargo de funcionario não encontrado.", "erro")
        return redirect(url_for("funcionario"))
    return render_template("lista_funcionario.html", funcionario=funcionario)

@app.route("/funcionario/atualizar/<int:id>", methods=["POST"])
def atualizar_funcionario(id):
    dados = get_funcionario_form()
    funcionario = Funcionario(**dados)
    erros = funcionario.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("fun.html", funcionario=dados)

    try:
        if not funcionario.find_by_id(id):
            flash("Funcionario não encontrado.", "erro")
            return redirect(url_for("funcionario"))

        funcionario.update(id)
        flash("Funcionario atualizado com sucesso.", "sucesso")
        return redirect(url_for("funcionario"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar funcionario: {e}", "erro")
        return render_template("fun.html", funcionario=dados)

@app.route("/funcionario/excluir/<int:id>", methods = ["DELETE"])
def excluir_funcionario(id):
    try:
        funcionario.delete(id)
        flash("Funcionario excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir funcionario: {e}", "erro")
    return redirect(url_for("funcionario"))

@app.route("/solicitador")
def solicitador():
    return render_template("lista_solicitador.html", solicitador=Solicitador.find_by_name(order_by="nome"))

@app.route("/solicitador/novo")
def novo_solicitador():
    return render_template("cad_sol.html")

@app.route("/solicitador/<int:id>", methods = ["GET"])
def findbyid_solicitador(id):
    solicitador = Solicitador.find_by_id(id)

    if not solicitador:
        return {"erro": "Solicitador não encontrado"}, 404
    return render_template("lista_solicitador.html")

@app.route("/solicitador/salvar", methods=["POST"])
def salvar_solicitador():
    dados = get_solicitador_form()
    solicitador = Solicitador(**dados)
    erros = solicitador.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("cad_sol.html", solicitador=dados)

    try:
        solicitador.insert()
        flash("Solicitador cadastrado com sucesso.", "sucesso")
        return redirect(url_for("solicitador"))
    except Exception as e:
        flash(f"Erro ao cadastrar solicitador: {e}", "erro")
        return render_template("cad_sol.html", solicitador=dados)

@app.route("/solicitador/listar/<int:id>", methods = ["GET"])
def listar_solicitador(id):
    solicitador = Solicitador.find_by_id(id)
    if not solicitador:
        flash("Solicitador não encontrado.", "erro")
        return redirect(url_for("solicitador"))
    return render_template("lista_solicitador.html", solicitador=solicitador)


@app.route("/solicitador/atualizar/<int:id>", methods=["POST"])
def atualizar_solicitador(id):
    dados = get_solicitador_form()
    solicitador = Solicitador(**dados)
    erros = solicitador.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("cad_sol.html", solicitador=dados)

    try:
        if not solicitador.find_by_id(id):
            flash("Solicitador não encontrado.", "erro")
            return redirect(url_for("solicitador"))

        solicitador.update(id)
        flash("Solicitador atualizado com sucesso.", "sucesso")
        return redirect(url_for("solicitador"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar solicitador: {e}", "erro")
        return render_template("cad_sol.html", solicitador=dados)

@app.route("/solicitador/excluir/<int:id>", methods = ["DELETE"])
def excluir_solicitador(id):
    try:
        solicitador.delete(id)
        flash("Solicitador excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir solicitador: {e}", "erro")
    return redirect(url_for("solicitador"))

@app.route("/localizacao")
def localizacao():
    return render_template("lista_localizacao.html", localizacao=Localizacao.find_by_name(order_by="rua"))

@app.route("/localizacao/novo")
def nova_localizacao():
    return render_template("localizacao.html")

@app.route("/localizacao/salvar", methods=["POST"])
def salvar_localizacao():
    dados = get_localizacao_form()
    localizacao = Localizacao(**dados)
    erros = localizacao.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("localizacao.html", localizacao=dados)

    try:
        localizacao.insert()
        flash("Localização cadastrada com sucesso.", "sucesso")
        return redirect(url_for("localizacao"))
    except Exception as e:
        flash(f"Erro ao cadastrar localizacao: {e}", "erro")
        return render_template("localizacao.html", localizacao=dados)

@app.route("/localizacao/listar/<int:id>", methods = ["GET"])
def listar_localizacao(id):
    localizacao = Localizacao.find_by_id(id)
    if not localizacao:
        flash("Localização não encontrada.", "erro")
        return redirect(url_for("localizacao"))
    return render_template("lista_localizao.html", localizacao=localizacao)

@app.route("/localizacao/atualizar/<int:id>", methods=["POST"])
def atualizar_localizacao(id):
    dados = get_localizacao_form()
    localizacao= Localizacao(**dados)
    erros = localizacao.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        return render_template("localizacao.html", solicitador=dados)

    try:
        if not localizacao.find_by_id(id):
            flash("Localização não encontrada.", "erro")
            return redirect(url_for("localizacao"))

        localizacao.update(id)
        flash("Localização atualizada com sucesso.", "sucesso")
        return redirect(url_for("localizacao"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar localização: {e}", "erro")
        return render_template("localizacao.html", localizacao=dados)

@app.route("/localizacao/excluir/<int:id>", methods = ["DELETE"])
def excluir_localizacao(id):
    try:
        localizacao.delete(id)
        flash("Localização excluída com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir localização: {e}", "erro")
    return redirect(url_for("localizacao.html"))

@app.route("/estoque", methods = ["GET"])
def listar_estoque():
   return render_template("lista_estoque.html", estoque=Estoque.find_all_stock())  

@app.route("/estoque/<int:id>", methods = ["GET"])
def listar_estoque_by_id():
   return render_template("lista_estoque.html", estoque=Estoque.find_product_by_id_stock(id))

@app.route("/item_solicitacao_entrada", methods = ["GET"])
def listar_itens():
   return render_template("mov_solicitacao_entrada.html", item_s_e=ItemSolicitacaoEntrada.find_all_with_product())

@app.route("/item_solicitacao_entrada/<int:id>", methods = ["GET"])
def listar_itens_by_id():
   return render_template("mov_solicitacao_entrada.html", item_s_e=ItemSolicitacaoEntrada.find_product_in_solicitacao(id))

@app.route("/item_solicitacao_entrada/inserir", methods = ["POST"])
def inserir():
    dados = get_item_solicitacao_entrada_form()
    item_s_entrada = ItemSolicitacaoEntrada(**dados)
    erros = item_s_entrada.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("mov_solicitacao_entrada.html", item_solicitacao_entrada=dados)
    try:
        item_s_entrada.insert()
        flash("Itens cadastrados com sucesso.", "sucesso")
        return redirect(url_for(""))
    except Exception as e:
        flash(f"Erro ao cadastrar os itens {e}", "erro")
        return render_template("mov_solicitacao_entrada.html", item_solicitacao_entrada=dados)

@app.route("/item_solicitacao_entrada/atualizar/<int:produto_id>", methods = ["POST"])
def atualizar_item():
    dados = get_item_solicitacao_entrada_form()
    item_s_entrada= ItemSolicitacaoEntrada(**dados)
    erros = item_s_entrada.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        dados["id"] = id
        dados["produto_id"] = "produto_id"
        return render_template("mov_solicitacao_entrada.html", item_solicitacao_entrada=dados)

    try:
        if not item_s_entrada.find_by_id(id):
            flash("Itens não encontrados.", "erro")
            return redirect(url_for("listar_item"))

        item_s_entrada.update("produto_id")
        flash("Itens atualizados com sucesso.", "sucesso")
        return redirect(url_for("listar_item"))
    except Exception as e:
        dados["id"] = id
        dados["produto_id"] = "produto_id"
        flash(f"Erro ao atualizar os itens: {e}", "erro")
        return render_template("mov_solicitacao_entrada.html", item_solicitacao_entrada=dados)
    
if __name__ == "__main__":
    app.run(debug=True)
''