#imports
from core.crud import Crud
from core.conexao import Database


#classe que representa um sensor no sistema
class ItemSolicitacaoEntrada(Crud):
    table = "item_solicitacao_entrada"
    #lista de campos da tabela
    fields = [
        "id_item_e",
        "id_operacao_e",
        "estoque_id"
    ]

    def _init_(self, id_item_e, id_operacao_e, estoque_id):
        self.id_item_e = id_item_e
        self.id_operacao_e = id_operacao_e
        self.estoque_id= estoque_id

        
    @classmethod
    def find_all_with_product(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT solicitacao_entrada.id_operacao_e,item_solicitacao_entrada.estoque_id FROM solicitacao_entrada INNER JOIN item_solicitacao_entrada ON solicitacao_entrada.id_operacao_e = item_solicitacao_entrada.id_operacao_e;"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def find_product_in_solicitacao(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT estoque.produto_id, item_solicitacao_entrada.id_item_e " \
            "FROM estoque " \
            "INNER JOIN item_solicitacao_entrada " \
            "ON estoque.produto_id = item_solicitacao_entrada.id_item_e;"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO item_solicitacao_entrada (estoque_id)
        VALUES (%s)
        """
        valores = (
            self.estoque_id
        )

        cursor.execute(sql, valores)
        conexao.commit()

        cursor.close()
        conexao.close()

    @classmethod
    def update(self):
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        UPDATE estoque
        SET produto_quantidade = %s
        WHERE produto_id = %s
        """
        valores = (
            self.produto_quantidade,
            self.produto_id
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()