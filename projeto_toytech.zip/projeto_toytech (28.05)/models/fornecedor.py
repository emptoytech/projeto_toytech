#imports
from core.conexao import Database
from core.crud import Crud
from core.validar import Validador

#classe que representa um fornecedor no sistema
class Fornecedor(Crud):

    table = "fornecedor"
    #lista de campos da tabela
    fields = [
        "id",
        "nome",
        "cnpj",
        "telefone"
    ]
    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome, cnpj, telefone):
        #atribui os valores aos objetos
        self.nome = nome
        self.cnpj = cnpj
        self.telefone = telefone
        
        
    
    #valida os dados do fornecedor
    def validate(self):

        #lista de possiveis erros
        erros = [
             Validador.required(self.nome, "nome"),
             Validador.not_have_number(self.nome, "nome"),
             Validador.required(self.cnpj, "cnpj"),
             Validador.not_have_scaracter(self.cnpj, "cnpj"),
             Validador.not_have_upper(self.nome,"nome"),
             Validador.non_negative(self.cnpj, "cnpj"),
             Validador.non_negative(self.telefone, "telefone"),
             Validador.count_to_14(self.cnpj, "cnpj"),
             Validador.count_to_9(self.telefone, "telefone")

            ]
        #retorna os erros
        return [erro for erro in erros if erro]

    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO fornecedor
        (nome, cnpj,telefone)
        VALUES (%s, %s, %s)
        """
        valores = (
            self.nome,
            self.cpf,
            self.telefone
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para listar fornecedor
    @classmethod
    def find_by_name():
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM fornecedor ORDER BY nome"
        cursor.execute(sql)
        fornecedor = cursor.fetchall()

        cursor.close()
        conexao.close()
        return fornecedor
    
    #metodo para buscar o id do fornecedor
    @classmethod
    def find_by_id(id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM fornecedor WHERE id = %s"
        cursor.execute(sql, (id,))
        fornecedor = cursor.fetchone()

        cursor.close()
        conexao.close()
        return fornecedor

    #metodo para atualizar fornecedor
    @classmethod
    def update(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        UPDATE fornecedor
        SET nome = %s,
            cnpj = %s,
            telefone = %s,
        WHERE id = %s
        """
        valores = (
            self.nome,
            self.cnpj,
            self.telefone
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para excluir fornecedor
    @classmethod
    def delete(id):
        conexao = Database.connect()
        cursor = conexao.cursor()


        sql = "DELETE FROM fornecedor WHERE id = %s"
        cursor.execute(sql, (id,))
        conexao.commit()

        cursor.close()
        conexao.close()