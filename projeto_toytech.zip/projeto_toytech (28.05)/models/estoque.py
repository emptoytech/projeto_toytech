from core.conexao import Database
from core.crud import Crud

#classe que representa um fornecedor no sistema
class Estoque(Crud):

    table = "estoque"
    #lista de campos da tabela
    fields = [
        "estoque_id",
        "produto_id",
        "produto_quantidade"
    ]
    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, estoque_id,produto_id=None, produto_quantidade = 0):
        #atribui os valores aos objetos
        self.estoque_id = estoque_id
        self.produto_id = produto_id
        self.produto_quantidade = produto_quantidade

    @classmethod
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = """
            INSERT INTO estoque
            (produto_quantidade)
            VALUES (%s)
        """
        valores = (
            self.produto_quantidade
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    @classmethod
    def find_all_stock():
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM estoque"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()
    
    @classmethod
    def find_product_by_id_stock(id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM estoque WHERE produto_id = %s"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()