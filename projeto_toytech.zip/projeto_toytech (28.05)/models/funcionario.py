#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador
#classe que representa um funcionario no sistema
class Funcionario(Crud):
    table = "funcionario"
    #lista de campos da tabela
    fields = [
        "id",
        "nome",
        "cpf",
        "email",
        "senha",
        "telefone",
        "cargo"
    ]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome, cpf, email, senha,
                 telefone, cargo):
        #atribui os valores aos objetos
        self.nome = nome
        self.cpf = cpf
        self.email = email
        self.senha = senha
        self.telefone = telefone
        self.cargo = cargo

    #valida os dados do funcionario
    def validate(self):
        #lista de possiveis erros
        erros = [
         Validador.required(self.nome, "nome"),
         Validador.non_negative(self.cpf, "cpf"),
         Validador.non_negative(self.email, "email"),
         Validador.non_negative(self.senha, "senha"),
         Validador.non_negative(self.telefone, "telefone"),
         Validador.non_negative(self.cargo, "cargo"),
         Validador.have_number(self.telefone, "telefone"),
         Validador.have_scaracter(self.email, "email"),
         Validador.count_to_8(self.senha, "senha"),
         Validador.count_to_11(self.cpf, "cpf"),
         Validador.count_to_9(self.telefone,"telefone"),
         Validador.not_have_upper(self.nome, "nome")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]

    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO funcionario
        (nome, cpf, email, senha, telefone, cargo)
        VALUES (%s, %s, %s, %s, %s,%s)
        """
        valores = (
            self.nome,
            self.cpf,
            self.email,
            self.senha,
            self.telefone,
            self.cargo
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()
    #retorna funcionarios na ordem alfabética de cargos
    @classmethod
    def find_by_cargo(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM funcionario ORDER BY cargo"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def find_by_name():
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM funcionario ORDER BY nome"
        cursor.execute(sql)
        funcionario = cursor.fetchall()

        cursor.close()
        conexao.close()
        return funcionario

    #metodo para buscar o id de funcionario
    @classmethod
    def find_by_id(id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM funcionario WHERE id = %s"
        cursor.execute(sql, (id,))
        funcionario = cursor.fetchone()

        cursor.close()
        conexao.close()
        return funcionario        

    #metodo para atualizar o funcionario
    @classmethod
    def update(self):
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        UPDATE funcionario
        SET nome = %s,
            cpf = %s,
            email = %s,
            senha = %s,
            telefone = %s,
            cargo = %s
        WHERE id = %s
        """
        valores = (
            self.nome,
            self.cnpj,
            self.email,
            self.senha,
            self.telefone,
            self.cargo
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para excluir funcionario
    @classmethod
    def delete(cls, id):
        funcionario = cls.find_by_id(id)
        if not funcionario:
            raise ValueError("Funcionario não encontrado.")
        cls.delete(id)