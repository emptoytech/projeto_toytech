#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa o produto
class Produto(Crud):
    table = "produto"
    #lista de campos da tabela
    fields = [
        "id",
        "nome",
        "descricao",
        "fornecedor_id",
        "localizacao_produto",
        "imagem",
        "preco"
    ]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome, descricao,
                 localizacao_produto, preco, fornecedor_id, imagem = None):
        #atribui os valores aos objetos
        self.nome = nome
        self.descricao = descricao
        self.fornecedor_id = fornecedor_id
        self.localizacao_produto = localizacao_produto
        self.imagem = imagem
        self.preco = preco

    #valida os dados do produto
    def validate(self):
        #lista de possiveis erros
        erros = [
         Validador.required(self.nome, "nome"),
         Validador.non_negative(self.descricao, "descricao"),
         Validador.non_negative(self.imagem, "imagem"),
         Validador.non_negative(self.preco, "preco"),
         Validador.not_have_upper(self.nome, "nome")
        ]
        #retorna os erros
        return [erro for erro in erros if erro],

    def cadastrar(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO produto
        (nome, descricao, imagem, preco)
        VALUES (%s, %s, %s, %s)
        """
        valores = (
            self.nome,
            self.descricao,
            self.imagem,
            self.preco
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    @classmethod
    def find_by_name():
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM produto ORDER BY nome"
        cursor.execute(sql)
        produto = cursor.fetchall()

        cursor.close()
        conexao.close()
        return produto

    @classmethod
    def find_by_id():
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM produto WHERE IS id = %s"
        cursor.execute(sql)
        produto = cursor.fetchall()

        cursor.close()
        conexao.close()
        return produto

#metodo para atualizar um produto
    @classmethod
    def update(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        UPDATE produto
        SET nome = %s,
            descricao = %s,
            imagem= %s,
            preco = %s
        WHERE id = %s
        """
        valores = (
            self.nome,
            self.descricao,
            self.imagem,
            self.preco
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()



    #metodo para deletar um produto
    @classmethod
    def safe_delete(cls, id):
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("Produto não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o produto porque ele possui solicitações ou movimentações vinculadas ou pendentes.")
        cls.delete(id)
