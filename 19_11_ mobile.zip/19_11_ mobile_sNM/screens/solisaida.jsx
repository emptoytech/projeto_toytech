//IMPORTACOES NECESSARIAS PARA O FUNCIONAMENTO DO PROJETO
import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ImageBackground,
  Alert
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import api from '../src/services/api';
import QRCodeScannerModal from '../QRCodeScannerModal';
import { Ionicons } from '@expo/vector-icons';

export default function SoliSaida({ navigation, route }) {
  const [quantity, setQuantity] = useState('');
  const [product, setProduct] = useState(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedId, setScannedId] = useState(null);

  const paramId = route?.params?.produto?.id ?? route?.params?.produto?.code;
  const targetId = scannedId ?? paramId;

  useEffect(() => {
    if (route?.params?.produto) {
      setScannedId(null);
      setProduct(route.params.produto);
    }
  }, [route?.params?.produto]);

  useFocusEffect(
    useCallback(() => {
      api.get('/produto')
        .then(res => {
          const lista = Array.isArray(res.data) ? res.data : [];
          if (lista.length > 0) {
            const encontrado = targetId != null
              ? lista.find(
                  p =>
                    String(p.id) === String(targetId) ||
                    String(p.code) === String(targetId)
                )
              : null;

            setProduct(encontrado || lista[0]);
          }
        })
        .catch(err => console.log('Erro ao atualizar estoque:', err));
    }, [targetId])
  );

  {/*QRCODE */}
  async function handleReadQRCode(data) {
    setIsScannerOpen(false);

    try {
      const response = await api.get('/produto');
      const lista = Array.isArray(response.data) ? response.data : [];
      const encontrado = lista.find(
        p =>
          String(p.id) === String(data).trim() ||
          String(p.code) === String(data).trim()
      );

      if (encontrado) {
        setProduct(encontrado);
        setScannedId(encontrado.id);
        Alert.alert(
          'Produto encontrado',
          `${encontrado.name}\nEstoque: ${encontrado.stock ?? 0}`
        );
      } else {
        setProduct(null);
        Alert.alert('Erro', 'Produto não encontrado.');
      }
    } catch (error) {
      console.log(error);
      Alert.alert('Erro', 'Erro ao buscar produto.');
    }
  }

  {/*SE NAO SELECIONAR NENHUM PRODUTO */}
  async function confirmarSaida() {
    const qtdNum = Number(quantity);

    if (!product) {
      Alert.alert('Erro', 'Nenhum produto selecionado.');
      return;
    }

    {/*SE A QUANTIDADE FOR IGUAL E MENOR QUE 0 */}
    if (!quantity || isNaN(qtdNum) || qtdNum <= 0) {
      Alert.alert('Erro', 'Insira uma quantidade válida.');
      return;
    }

    {/*SE TENTAR TIRAR DO ESTOQUE UMA QUANTIDADE QUE SUPERA QUANTIDADE ATUAL */}
    const estoqueAtual = Number(product.stock ?? 0);

    if (qtdNum > estoqueAtual) {
      Alert.alert('Erro', 'Quantidade solicitada é maior que o estoque atual.');
      return;
    }

    {/*SE DER CERTO A RETIRADA DO PRODUTO */}
    try {
      await api.post('/stock/move', {
        productId: product.id,
        type: 'Saída',
        quantity: parseInt(quantity),
      });

      Alert.alert('Sucesso', 'Saída realizada com sucesso!', [
        {
          text: 'OK',
          onPress: () => {
            setQuantity('');
            navigation.goBack();
          }
        },
      ]);
    } catch (error) {
      Alert.alert('Erro', error.response?.data?.message || 'Erro ao registrar saída.');
    }
  }

  // Cálculo do estoque final
  const estoqueAtual = Number(product?.stock ?? 0);
  const qtdInserida = Number(quantity || 0);
  const remainingStock = estoqueAtual - qtdInserida;
  const estoqueFinal = remainingStock < 0 ? 0 : remainingStock;
  const productName = product ? product.name : 'Nenhum produto selecionado';
  const productCode = product ? (product.code || product.id) : '-';

  {/*IMAGEM DE FUNDO */}
  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
      >
        {/*BOTAO PRA VOLTAR A PAGINA ANTERIOR */}
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.botaovoltar}
        >
          <Ionicons
            name="arrow-back"
            size={30}
            color="#fff"
          />
        </TouchableOpacity>

        {/*Header */}
        <View style={styles.header}>
          <Text style={styles.title}>
            Saída de Estoque
          </Text>

          <Text style={styles.subtitle}>
            Retire produtos rapidamente
          </Text>
        </View>

        {/*Qr code */}
        <TouchableOpacity
          style={styles.qrButton}
          onPress={() => setIsScannerOpen(true)}
        >
          <View style={styles.qrContent}>
            <Ionicons
              name="qr-code-outline"
              size={32}
              color="#fff"
            />

            <View>
              <Text style={styles.qrTitle}>
                Ler QR Code
              </Text>

              <Text style={styles.qrSubtitle}>
                Escanear produto
              </Text>
            </View>
          </View>

          <Ionicons
            name="chevron-forward"
            size={22}
            color="#fff"
          />
        </TouchableOpacity>

        <QRCodeScannerModal
          visible={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          onReadCode={handleReadQRCode}
        />

        {/*Produto */}
        <Text style={styles.sectionTitle}>
          Produto Encontrado
        </Text>

        <View style={styles.productCard}>
          <View style={styles.productIcon}>
            <Ionicons
              name="cube"
              size={28}
              color="#FF6B6B"
            />
          </View>

          <View style={{ flex: 1 }}>
            <Text style={styles.productName}>
              {productName}
            </Text>

            <Text style={styles.productCode}>
              Código: {productCode}
            </Text>

            <Text style={styles.productStock}>
              Estoque Atual: {estoqueAtual}
            </Text>
          </View>
        </View>

        {/*Quantidade */}
        <Text style={styles.sectionTitle}>
          Quantidade
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Digite a quantidade"
          placeholderTextColor="#94A3B8"
          keyboardType="numeric"
          value={quantity}
          onChangeText={setQuantity}
        />

        {/*Resumo */}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>
            Resumo da Saída
          </Text>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>
              Produto
            </Text>

            <Text style={styles.summaryValue}>
              {productName}
            </Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>
              Quantidade
            </Text>

            <Text style={styles.summaryValue}>
              {quantity || 0}
            </Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>
              Estoque Final
            </Text>

            <Text style={styles.summaryValueRed}>
              {estoqueFinal}
            </Text>
          </View>
        </View>

        {/*Botao pra confirmar */}
        <TouchableOpacity
          style={styles.confirmButton}
          onPress={confirmarSaida}
        >
          <Ionicons
            name="remove-circle"
            size={24}
            color="#fff"
          />

          <Text style={styles.confirmText}>
            Confirmar Saída
          </Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    paddingHorizontal: 20,
  },
  botaovoltar: {
    marginTop: 20,
    alignSelf: 'flex-start',
  },
  header: {
    marginTop: 20,
  },
  title: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold',
  },
  subtitle: {
    color: '#ffffff',
    marginTop: 5,
    fontSize: 15,
  },
  qrButton: {
    backgroundColor: '#3c5fbc',
    borderRadius: 25,
    padding: 22,
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  qrContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  qrTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  qrSubtitle: {
    color: '#ffffff',
    fontSize: 15,
    marginTop: 3,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 15,
  },
  productCard: {
    backgroundColor: '#1E293B',
    borderRadius: 22,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  productIcon: {
    width: 65,
    height: 65,
    backgroundColor: '#3B1822',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  productName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  productCode: {
    color: '#ffffff',
    marginTop: 5,
  },
  productStock: {
    color: '#FF6B6B',
    marginTop: 8,
    fontWeight: 'bold',
  },
  input: {
    backgroundColor: '#1E293B',
    height: 65,
    borderRadius: 18,
    paddingHorizontal: 20,
    color: '#ffffff',
    fontSize: 18,
  },
  summaryCard: {
    backgroundColor: '#1E293B',
    borderRadius: 22,
    padding: 22,
    marginTop: 35,
  },
  summaryTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  summaryLabel: {
    color: '#ffffff',
    fontSize: 15,
  },
  summaryValue: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  summaryValueRed: {
    color: '#FF6B6B',
    fontWeight: 'bold',
  },
  confirmButton: {
    backgroundColor: '#c72f2f',
    height: 65,
    borderRadius: 22,
    marginTop: 35,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  confirmText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});