// IMPORTAÇÕES NECESSÁRIAS PARA O FUNCIONAMENTO DA TELA
import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import api from '../src/services/api';

export default function Historico({ scrollEnabled = true }) {
  const [history, setHistory] = useState([]);

  const loadHistory = async () => {
    try {
      const response = await api.get('historico');

      // Função que converte a data e a hora
      const parseDateTime = (item) => {
        const dateStr = item.date || item.data;
        if (!dateStr) return 0;

        const [day, month, year] = dateStr.split('/');
        const hourStr = item.hour || item.hora || '00:00';
        const [hours, minutes] = hourStr.split(':');

        // Retorna o horário para ordenação exata
        return new Date(year, month - 1, day, hours || 0, minutes || 0).getTime();
      };

      // Ordena do mais recente para o mais antigo
      const formattedData = [...response.data].sort((a, b) => parseDateTime(b) - parseDateTime(a));

      setHistory(formattedData);
    } catch (error) {
      console.log('Erro ao carregar histórico:', error);
    }
  };

  // Atualiza o histórico sempre que a ecrã ganha foco
  useFocusEffect(
    useCallback(() => {
      loadHistory();
    }, [])
  );

  // Renderização do cabeçalho da lista
  const renderHeader = () => (
    <Text style={styles.title}>Histórico Recente</Text>
  );

  // Caso nenhum produto esteja selecionado
  const renderEmpty = () => (
    <Text style={styles.emptyText}>Nenhuma movimentação registrada.</Text>
  );

  const conteudoLista = (
    <FlatList
      data={history}
      scrollEnabled={scrollEnabled}
      keyExtractor={(item, index) => (item.id ? item.id.toString() : index.toString())}
      showsVerticalScrollIndicator={false}
      ListHeaderComponent={renderHeader}
      ListEmptyComponent={renderEmpty}
      renderItem={({ item }) => (
        <View style={styles.lineItem}>
          <View style={styles.leftContent}>
            <Ionicons
              name={item.type === 'Entrada' ? 'checkmark-circle' : 'close-circle'}
              size={22}
              color={item.type === 'Entrada' ? '#22C55E' : '#EF4444'}
            />
            <Text style={styles.productText} numberOfLines={1}>
              {item.product}
            </Text>
            <Text
              style={[
                styles.typeTag,
                { color: item.type === 'Entrada' ? '#22C55E' : '#EF4444' },
              ]}
            >
              ({item.type})
            </Text>
          </View>

          <Text style={styles.rightContent}>
            {item.quantity ? `${item.quantity} un • ` : ''}{item.date}
          </Text>
        </View>
      )}
    />
  );

  if (!scrollEnabled) {
    return <View style={{ marginTop: 20 }}>{conteudoLista}</View>;
  }

  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.container}
      resizeMode="cover"
    >
      {conteudoLista}
    </ImageBackground>
  );

}

// Estilo da interface
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 16,
  },
  title: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  emptyText: {
    color: '#94A3B8',
    fontSize: 14,
    fontStyle: 'italic',
    marginTop: 5,
  },
  lineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(30, 41, 59, 0.9)',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  leftContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    marginRight: 10,
  },
  productText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    flexShrink: 1,
  },
  typeTag: {
    fontSize: 13,
    fontWeight: 'bold',
  },
  rightContent: {
    color: '#94A3B8',
    fontSize: 13,
  },
});
